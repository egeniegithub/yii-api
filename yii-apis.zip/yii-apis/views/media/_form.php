<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Media */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="media-form">

    <?php $form = ActiveForm::begin([
          'options'=>['enctype'=>'multipart/form-data']]); ?>

    <?= $form->field($model, 'image_name')->fileInput(['maxlength' => true,'id'=>'image_file']) ?>

     <?= $form->field($model, 'created_at')->textInput() ?> 
      <?= $form->field($model, 'height')->textInput(['id'=>'height']) ?> 
       <?= $form->field($model, 'width')->textInput(['id'=>'width']) ?> 

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
