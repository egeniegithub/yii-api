<?php

namespace app\controllers;
use yii;

class FileUploadController extends \yii\web\Controller
{

    public function actionUploadfile(){
    	echo "fileupload controller ";
    	die();
    	return $this->render('index');
    }

}
