<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "images".
 *
 * @property int $id
 * @property string $image_name
 * @property int $fk_artist_id
 * @property string $width
 * @property string $height
 * @property string $created_at
 * @property string $updated_at
 *
 * @property NewUser $fkArtist
 */
class Images extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'images';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['image_name', 'fk_artist_id', 'width', 'height'], 'required'],
            [['fk_artist_id'], 'integer'],
            [['created_at', 'updated_at'], 'safe'],
            [['image_name'], 'string', 'max' => 200],
            [['width', 'height'], 'string', 'max' => 50],
            [['fk_artist_id'], 'exist', 'skipOnError' => true, 'targetClass' => NewUser::className(), 'targetAttribute' => ['fk_artist_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'image_name' => 'Image Name',
            'fk_artist_id' => 'Fk Artist ID',
            'width' => 'Width',
            'height' => 'Height',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getFkArtist()
    {
        return $this->hasOne(NewUser::className(), ['id' => 'fk_artist_id']);
    }
}
