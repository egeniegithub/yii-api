<?php

namespace app\models;

use Yii;
use yii\db\Query;

/**
 * This is the model class for table "media".
 *
 * @property int $id
 * @property string $image_name
 * @property string $created_at
 */
class Media extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'media';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['image_name','height','width'], 'required'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'image_name' => 'Image Name',
            'filepath' => 'File Path',
            'height'    =>  'Height',
            'width' => 'Width',
            'username' => 'User Name',
            'user_id' => 'User Id'
        ];
    }

    public function fields() {
        return[
            'id',
            'image_name',
            'filepath',
            'width',
            'height',
            'user_id',
            'created_at',
        ];
    }
    public function getAllCollections(){
        $query = new Query;
        $query  ->select(['media.*', 'new_user.username','new_user.email','new_user.filepath as userimage'])  
        ->from('media')
        ->leftJoin('new_user', 'new_user.id = media.user_id')->orderBy(['id' => SORT_DESC]);
        $command = $query->createCommand();
        $data = $command->queryAll();
        return $data;
    }
    public function findByUserId($user_id){
 
       $query = new Query;
        $query  ->select(['media.*', 'new_user.username','new_user.email','new_user.filepath as userimage'])  
        ->from('media')
        ->leftJoin('new_user', 'new_user.id = media.user_id')->where(['user_id' => $user_id])->orderBy(['id' => SORT_DESC]);
        $command = $query->createCommand();
        $data = $command->queryAll();
        return $data;
    }
  
    public function upload()
    {
        if ($this->validate()) {
            $this->imageFile->saveAs('uploads/' . $this->imageFile->baseName . '.' . $this->imageFile->extension);
            return true;
        } else {
            return false;
        }
    }
}
