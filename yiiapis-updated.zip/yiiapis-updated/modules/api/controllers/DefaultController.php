<?php

namespace app\modules\api\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\NewUser;
use app\models\Media;
use yii\helpers\ArrayHelper;
use yii\db\ActiveRecord;    
use yii\rest\ActiveController;
use yii\web\UploadedFile;

   class DefaultController extends ActiveController {



    public $enableCsrfValidation = false;
      public $modelClass = 'app\models\MediaSearch';
      public function behaviors()
        {
            return [
                'corsFilter' => [
                    'class' => \yii\filters\Cors::className(),
                    'cors' => [
                        'Origin' => ['*'],
                        'Access-Control-Request-Method' => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'],
                        'Access-Control-Request-Headers' => ['*'],
                        'content-type'=> ['multipart/form-data'],
                        "Access-Control-Allow-Origin"=>["*"],
                        "Access-Control-Allow-Headers"=>["Origin, X-Requested-With, Content-Type, Accept"],
                    ],

                ],
            ];
        }



      public function actionIndexpage(){
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $models =  Media::find()->all();
        if(!empty($models)){
            return array('data'=>$models);
        }else{
            return array('status'=>false,'data'=>$models->getErrors());
        }
      }
      // login api
      public function actionLogin(){
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $data = Yii::$app->request->post();
        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post(), '') && $model->login()) {
            if (!Yii::$app->user->isGuest) {
                $user = $model->getUser();
                $user_id = $user->id;
                $medias = new Media();
                $collections = $medias->findByUserId($user_id);
                $allData = array();
                // array_push($allData,['user'=>$user,'collection'=>$collections]);
                // return array('status'=>true,'data'=>$allData);
                // die();
                return array('status'=>true,'data'=>$user);
            }
            $model = new LoginForm();
            if ($model->load(Yii::$app->request->post()) && $model->login()) {
                return array('status'=>true,'data'=>$model);
                return $this->goBack();
            }
            $model->password = '';
            return array('status'=>true,'data'=>$model);
        }else{
            return array('status'=>'false else data conditions ','data'=>$model->getErrors());
            return $model->getErrors();
        }
      }
      // register apis 
      public function actionRegister()
      {
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $model = new NewUser();
        if ($model->load(Yii::$app->request->post())) {
            return array('data'=>$model);
            if ($model->validate()) {    
                $model->username = $_POST['fname'].' '.$_POST['fname'];
                $model->fname = $_POST['fname'];
                $model->lname = $_POST['lname'];
                $model->email = $_POST['email'];
                $model->address = $_POST['address'];
                $model->account = $_POST['account'];
                $model->password = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $model->authKey = md5(random_bytes(5));
                $model->accessToken = password_hash(random_bytes(10),PASSWORD_DEFAULT);
                $model->workexperience = $_POST['workexperience'];
                 return array('status'=>true,'data'=>$model);
                if($model->save()){
                    return array('status',true,'data'=>'user created successfully ');
                }
            }else{
                return array('status'=>'validation errors ','data'=>$model->getErrors());
            }
        }else{
            return array('status'=>'cannot load data','data'=>$model->getErrors());
        }

        $data = Yii::$app->request->post();
        if(!empty($data)){
            return array('data'=>$data);
        }else{
            return array('status'=>false);
        }
        $model = new NewUser();
        $model->scenario = NewUser::SCENATIO_CREATE;
        $model->attributes = \Yii::$app->request->post();
        return array('data'=>$data);
        $model = new RegisterForm();
        if ($model->load($dataRequest)) {
            if ($user = $model->register()) {
                return $this->apiCreated($user);
            }
        }
        return $this->apiValidate($model->errors);
     }

     public function actionCollections(){
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $accessToken = Yii::$app->request->post();
        $user = new NewUser();
        $users = $user->getIdByAccessToken($accessToken);
        $user_id = $users[0]['id'];
        $medias = new Media();
        $collections = $medias->findByUserId($user_id);
        return array('status'=>true,'data'=>$collections);
    }   
    public function actionGetallcollection(){
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $model = new Media();
        $dataProvider = $model->getAllCollections();
        return array('status'=>true,'data'=>$dataProvider);
    }

    public function actionUploadimage(){
        $model = new Media();
        $uploadPath = 'uploads/';
        $file = $_FILES["file"]['tmp_name'];
        list($width, $height) = getimagesize($file);
        if (isset($_FILES['file'])) {
        $file = \yii\web\UploadedFile::getInstanceByName('file');
            $path = 'uploads/'.md5($file->baseName).'.'.$file->extension;
            if($file->saveAs($path)){
                $accessToken = $_POST['accessToken'];
                $user = new NewUser();
                $users = $user->getIdByAccessToken($accessToken);
                $user_id = $users[0]['id'];
                $model->image_name = $file->baseName.'.'.$file->extension;
                $model->filepath = $path;
                $model->height = $width;
                $model->width = $height;
                $model->user_id = $user_id;
                if($model->save()){
                       return array('status'=>true,'message'=>'image save successfully ');
                }

            }

    }else{
        echo "else part";
        die();
    }
        return array('status'=>true,'data'=>$model->getErrors());
    }

    public function actionSinglecollection($collectionId){
        \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
        $data = Media::find()
            ->select('media.*, new_user.username,new_user.email,new_user.account,new_user.workexperience,new_user.address,new_user.fname,new_user.lname')
            ->leftJoin('new_user', 'new_user.id = media.user_id')
            ->where(['media.id' => $collectionId])
            ->asArray()
            ->all();
        return array('status'=>true,'data'=>$data);
    }

}
