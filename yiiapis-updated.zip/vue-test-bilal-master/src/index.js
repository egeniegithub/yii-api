import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

import auth from './auth'
import App from './components/App.vue'
import ArtWork from './components/ArtWork.vue'
import Login from './components/Login.vue'
import FileUpload from './components/fileupload.vue'
import SignUpForm from './components/SignUpform.vue'
import ImageDetail from './components/ImageDetail.vue'

function requireAuth (to, from, next) {
  if (!auth.loggedIn()) {
    next({
      path: '/login',
      query: { redirect: to.fullPath }
    })
  } else {
    next()
  }
}

const router = new VueRouter({
  mode: 'history',
  routes: [
    { path: '/#', component: App },
    { path: '/art-work', component: ArtWork, beforeEnter: requireAuth },
    { path: '/login', component: Login },
    { path: '/logout',
      beforeEnter (to, from, next) {
        auth.logout()
        next('/')
      }
    },
    {path: '/fileupload',component: FileUpload},
    {path: '/signupform',component: SignUpForm},
    {path: '/imageDetail/:userid',component: ImageDetail},
  ]
})

export default {
  router,
  render: h => h(App)
}
