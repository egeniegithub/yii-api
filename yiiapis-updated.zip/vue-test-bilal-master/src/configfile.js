export default{

  getAPiPath(){
    return "http://localhost:8080/api/";
  },
  getImagePath(){
    return "http://localhost:8080/";
  }

}
