<template>
    <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 mt-4" v-for="item in allData"> 
                <div class="card card-inverse card-info">
                    <img class="card-img-top" :src="`http://localhost:8080/${item.filepath}`" width="100%" height="400px">
                    <div class="card-block">
                       <!-- <h4 class="card-title">{{item.username}}</h4> -->
                        <div class="card-text">
                            <figure class="">
                            <img :src="`http://localhost:8080/${item.userimage}`" class="profile-avatar" alt="" style="border-radious:80px; width:30px; !important; height:30px !important;">
                        </figure>
                        <table class="table">
      
      <tbody>
      <tr>
        <td colspan="2" style="margin-top:none;">
            <h1 class="text-center">  Artist Details </h1>
        </td>
      </tr>
        <tr>
          <td>Name</td>
          <td>{{item.username}}</td>  
        </tr>
        <tr>
          <td>Account</td>
          <td>{{item.account}}</td>
        </tr>
        <tr>
          <td>Work Experience</td>
          <td>{{item.workexperience}}</td>
        </tr>
        <tr>
          <td colspan="2" style="margin-top:none;">
            <h1 class="text-center">  Collection Image Detail </h1>
        </td>
        </tr>
        <tr>
          <td>Width</td>
          <td>{{item.width}}px</td>
        
        </tr>
        <tr>
          <td>Width</td>
          <td>{{item.width}}px</td>
        
        </tr>
        <tr>
          <td>Published</td>
          <td>{{item.created_at}} </td>
      
        </tr>
      </tbody>
    </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <small>Published: {{item.created_at}}</small>
                    </div>
                </div>
            </div>
        </div>
</template>


<script>
import auth from '../auth';
import axios from 'axios';
import configFile from '../configfile.js';

// console.log($route.params.userid);
export default {
    data(){
        return{
            allData:[],
            current_user: "",
        }
    },
    methods:{

    },
    mounted() {
    const that = this;
    this.current_user = this.$route.params.userid;
    axios.get(configFile.getAPiPath()+'default/singlecollection?collectionId='+that.current_user).then(response => {
        const list = [];
            this.list = response.data.data;
            that.allData = this.list;
            // console.log(this.list);
    }).catch(error => {
    //   console.log(error);
    });
  },

}
</script>