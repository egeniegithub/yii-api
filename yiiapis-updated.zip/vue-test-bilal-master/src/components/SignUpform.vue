<template>
    <form method="post" id="signupForm" @submit="formSubmit">
    <div class="row">
        <div class="col-sm-6">
            <div class="form-group">
                <label>First Name</label>
                <input type="text" name="fname" id="fname" class="form-control" required="required" v-model="fname">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Last Name</label>
                <input type="text" name="lname" id="lname" class="form-control" required="required" v-model="lname">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" id="email" class="form-control" required="required" v-model="email">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" id="password" class="form-control" required="required" v-model="password">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Address</label>
                <input type="text" name="address" id="address" class="form-control" required="required" v-model="address">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Account</label>
                <input type="text" name="account" id="account" class="form-control" required="required" v-model="account">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Work Experience</label>
                <input type="text" name="workexperience" id="workexperience" class="form-control" required="required" v-model="workexperience">
            </div>
        </div>
        <div class="col-sm-12">
            <input type="submit" value="Save" class="btn btn-primary">
        </div>
    </div>
    </form>
</template>



<script>

    import axios from 'axios';

    export default {
        data(){
            return {
                fname:'',
                lname:'',
                email:'',
                password:'',
                address:'',
                account:'',
                workexperience:'',

            }
        },
        methods:{
            formSubmit(e) {
                e.preventDefault();
                let currentObj = this;
                   var headers = { 
                        'Origin':'*',
                        'Access-Control-Request-Method':'GET,POST, PUT,PATCH,DELETE,HEAD,OPTIONS',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Request-Headers':'*',
                        "Access-Control-Allow-Headers":"Origin,Methods, X-Requested-With, Content-Type, Accept",
                        "Access-Control-Allow-Methods": "POST",
                        }

                // const formData = new FormData();
                const data = {
                    'fname':this.fname,
                    'lname':this.lname,
                    'email':this.email,
                    'password':this.password,
                    'address':this.address,
                    'account':this.account,
                    'workexperience':this.workexperience,     
                    'username':this.fname+' '+this.lname,    
                };
                console.log(data);
                axios.post('http://localhost:8080/api/default/register',
                {
                    'fname':this.fname,
                    'lname':this.lname,
                    'email':this.email,
                    'password':this.password,
                    'address':this.address,
                    'account':this.account,
                    'workexperience':this.workexperience,     
                    'username':this.fname+' '+this.lname}
                    ,headers)
                .then(function (response) {
                    console.log(response);
                        // currentObj.$router.replace(currentObj.$route.query.redirect || '/art-work')
                    // currentObj.success = response.data.success;
                })
                .catch(function (error) {
                    currentObj.output = error;
                });
            }
        },
    }

</script>