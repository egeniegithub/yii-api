<style>
  html {
    font-family: Lato, 'Helvetica Neue', Arial, Helvetica, sans-serif;
    font-size: 14px;
}

h5 {
    font-size: 1.28571429em;
    font-weight: 700;
    line-height: 1.2857em;
    margin: 0;
}

.card {
    font-size: 1em;
    overflow: hidden;
    padding: 0;
    border: none;
    border-radius: .28571429rem;
    box-shadow: 0 1px 3px 0 #d4d4d5, 0 0 0 1px #d4d4d5;
}

.card-block {
    font-size: 1em;
    position: relative;
    margin: 0;
    padding: 1em;
    border: none;
    border-top: 1px solid rgba(34, 36, 38, .1);
    box-shadow: none;
}

.card-img-top {
    display: block;
    width: 100%;
    height: auto;
}

.card-title {
    font-size: 1.28571429em;
    font-weight: 700;
    line-height: 1.2857em;
}

.card-text {
    clear: both;
    margin-top: .5em;
    color: rgba(0, 0, 0, .68);
}

.card-footer {
    font-size: 1em;
    position: static;
    top: 0;
    left: 0;
    max-width: 100%;
    padding: .75em 1em;
    color: rgba(0, 0, 0, .4);
    border-top: 1px solid rgba(0, 0, 0, .05) !important;
    background: #fff;
}

.card-inverse .btn {
    border: 1px solid rgba(0, 0, 0, .05);
}

.profile {
    position: absolute;
    top: -12px;
    display: inline-block;
    overflow: hidden;
    box-sizing: border-box;
    width: 25px;
    height: 25px;
    margin: 0;
    border: 1px solid #fff;
    border-radius: 50%;
}

.profile-avatar {
    display: block;
    width: 100%;
    height: 100%;
    border-radius: 50%;
}

.profile-inline {
    position: relative;
    top: 0;
    display: inline-block;
}

.profile-inline ~ .card-title {
    display: inline-block;
    margin-left: 4px;
    vertical-align: top;
}

.text-bold {
    font-weight: 700;
}

.meta {
    font-size: 1em;
    color: rgba(0, 0, 0, .4);
}

.meta a {
    text-decoration: none;
    color: rgba(0, 0, 0, .4);
}

.meta a:hover {
    color: rgba(0, 0, 0, .87);
}
</style>
<template>
  <div id="app">
    <header>
      <nav class="navbar navbar-expand-md navbar-dark bg-dark">
        <a class="navbar-brand" href="/#">Home</a>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <router-link to="/art-work" class="nav-link">Art Work</router-link>
            </li>
            <li>
              <router-link v-if="loggedIn" to="/fileupload" class="nav-link">File Upload</router-link>
            </li>
            <li class="nav-item">
              <router-link v-if="loggedIn" to="/logout" class="nav-link">Log out</router-link>
              <router-link v-if="!loggedIn" to="/login" class="nav-link">Log in</router-link>
            </li>
            <!--
            <li class="nav-item">
              <router-link v-if="!loggedIn" to="/signupform" class="nav-link">SignUp</router-link>
            </li>  -->
            
          </ul>
        </div>
      </nav>
    </header>
    
    <div class="row" style="margin:0px auto !important;"> 
      <div class="container">
        <div class="col-md-12 mt-5">
          <template v-if="$route.matched.length">
            <router-view></router-view> 
          </template>
          <template v-else>
            <div class="row">
            <div class="col-sm-6 col-md-4 col-lg-3 mt-4" v-for="item in allData">
                <div class="card card-inverse card-info">
                    <router-link v-bind:to="'/imageDetail/' + item.id">
                    <img class="card-img-top" :src="`http://localhost:8080/${item.filepath}`" style="width:100% !important; height:200px !important;">
                   </router-link>
                    <div class="card-block">
                        <figure class="">
                            <img :src="`http://localhost:8080/${item.userimage}`" class="profile-avatar" alt="" style="border-radious:80px; width:30px; !important; height:30px !important;">
                        </figure>
                        <h4 class="card-title">{{item.username}}</h4>
                        <div class="card-text">
                          
                        </div>
                    </div>
                    <div class="card-footer">
                        <small>Published: {{item.created_at}}</small>
                       <!-- <button class="btn btn-info float-right btn-sm"></button> -->
                    </div>
                </div>
            </div>
        </div>
           <!-- <div class="col-md-12 mt-5 ">
              <gallery :images="images" :index="index" @close="index = null"></gallery>
              <div
                class="image"
                v-for="(image, imageIndex) in images"
                :key="imageIndex"
                @click="index = imageIndex"
                :style="{ backgroundImage: 'url(' + image + ')', width: '300px', height: '200px' }"
              >
         
              </div>  
              
            </div>  -->
            <p>
             <!-- {{ loggedIn ? 'Welcome To Art Work' : 'You need to login first to see the art work.' }} -->
            </p>
          </template>
        </div>  
      </div>
    </div>
  </div>
</template>

<script>
import VueGallery from 'vue-gallery';
import auth from '../auth';
import axios from 'axios';
import configFile from '../configfile.js';

export default {
  data () {
    return {
      images: [],
       index: null,
      loggedIn: auth.loggedIn(),
      allData:[]
    }
  },
  mounted() {
    const that = this;
    axios.get(configFile.getAPiPath()+'default/getallcollection').then(response => {
      // console.log(response);
          let list=[];
              response.data.data.map(function(value, key) {
                  list.push(configFile.getImagePath()+ value.filepath);
              });
              that.images = list;
              that.allData = response.data.data;
    }).catch(error => {
      console.log(error);
    });
  },
  created () {
    auth.onChange = loggedIn => {
      this.loggedIn = loggedIn
    }
  },
  components: {
      'gallery': VueGallery
    },
}
</script>


<style scoped>
  .image {
    float: left;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
    border: 1px solid #ebebeb;
    margin: 5px;
  }
  .col-mb-5 {
  	margin-bottom: 50px;
  }
</style> 