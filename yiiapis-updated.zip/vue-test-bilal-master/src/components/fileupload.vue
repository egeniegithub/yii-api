<template>
    <div class="row">
        <form @submit="formSubmit" enctype="multipart/form-data">
            <div class="col-sm-12">
                <div class="form-group">
                    <label>FIle Upload</label>
                    <input type="file" name="fileupload" id="fileupload" class="form-control"  v-on:change="onFileChange"> 
                </div>
            </div>
            <input type="hidden" name="height" id="height">
            <input type="hidden" name="width" id="width">
            <div class="col-sm-12">
                <div class="form-group">
                    <input type="submit" value="Upload File" class="btn btn-primary" >
                </div>
            </div>
        </form>
    </div>
</template>

<script>

    import auth from '../auth';
    import axios from 'axios';
    import uploader from 'vue-simple-uploader';
    export default {
        mounted() {
            console.log('Component mounted.')
        },
        data() {
            return {
              name: '',
              file: '',
              success: '',
              accessToken:'',
            };
        },
        methods: {
            onFileChange(e){
                this.file = e.target.files[0];
                var getimage = this.file.size;
               
            },
        
            formSubmit(e) {
                e.preventDefault();
                let currentObj = this;
                const accessToken = auth.getToken();
                   var headers = { 
                        'Origin':'*',
                        'Access-Control-Request-Method':'GET,POST, PUT,PATCH,DELETE,HEAD,OPTIONS',
                        'Access-Control-Allow-Origin': '*',
                        'content-type': 'multipart/form-data',
                        'Access-Control-Request-Headers':'*',
                        "Access-Control-Allow-Headers":"Origin,Methods, X-Requested-With, Content-Type, Accept",
                        "Access-Control-Allow-Methods": "POST",
                        }

                const formData = new FormData();
                formData.append('file', this.file,this.file.name);
                formData.append('accessToken',accessToken)
                axios.post('http://localhost:8080/api/default/uploadimage',formData,headers)
                .then(function (response) {
                    // console.log(response);
                        currentObj.$router.replace(currentObj.$route.query.redirect || '/art-work')
                    currentObj.success = response.data.success;
                })
                .catch(function (error) {
                    currentObj.output = error;
                });
            }
        }
    }


</script>