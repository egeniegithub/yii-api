-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2019 at 09:31 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(11) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `filepath` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `height` int(100) NOT NULL,
  `width` int(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `image_name`, `filepath`, `user_id`, `height`, `width`, `created_at`) VALUES
(1, 'pexels-photo-248797.jpeg', 'uploads/80d2af586435bf06f11cc5443847404d.jpeg', 1, 0, 0, '2019-07-22 11:05:23'),
(2, 'pexels-photo-248797.jpeg', 'uploads/80d2af586435bf06f11cc5443847404d.jpeg', 1, 0, 0, '2019-07-22 11:08:32');

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1563560209),
('m190719_191936_media', 1563563986);

-- --------------------------------------------------------

--
-- Table structure for table `new_user`
--

CREATE TABLE `new_user` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `account` varchar(100) NOT NULL,
  `workexperience` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL,
  `authKey` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `new_user`
--

INSERT INTO `new_user` (`id`, `username`, `fname`, `lname`, `email`, `address`, `account`, `workexperience`, `password`, `authKey`, `accessToken`, `created_at`, `updated_at`) VALUES
(1, 'Haider', 'Haider', 'Ali', 'ali@gmail.com', 'lahore', 'account', '4', '$2y$10$nbqR9xwfXgL4X42o.L.taO2c34jVsUMaSnhs1jQ65oQ6qStCQ7Xq2', '3653e1cc0c53dcfaaccad4cf17694b41', '$2y$10$JRu2.zNlh8lWABkIueymXOUEZweps5.d94Pt4oFwEVfaBCMMFhN/q', '2019-07-19 18:11:41', '2019-07-19 18:11:41'),
(2, '', 'Ghulam', 'Haider', 'haider@gmail.com', 'lahore', 'account', '3', '$2y$10$AgHXc00iI55rX.QpbhPfCeXxMvh3a8fNGRiH7PKtDhY938m1lF5iO', '92e2d5df0aba25eb48a5ab883fd80287', '$2y$10$t/3SKWeYDv5dle/gWI2HL.yAi6pOdJvqDqNaY87vrZVt1ZYip0hDy', '2019-07-22 10:26:46', '2019-07-22 10:26:46');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `new_user`
--
ALTER TABLE `new_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `new_user`
--
ALTER TABLE `new_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `media`
--
ALTER TABLE `media`
  ADD CONSTRAINT `media_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `new_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
