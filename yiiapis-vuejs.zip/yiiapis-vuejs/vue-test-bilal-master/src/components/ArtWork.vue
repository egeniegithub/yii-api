<template>
  <div class="col-mb-10">
    <h2>Art Work</h2>
    <div class="col-md-12 mt-5 ">
    	<gallery :images="images" :index="index" @close="index = null"></gallery>
	    <div
	      class="image"
	      v-for="(image, imageIndex) in images"
	      :key="imageIndex"
	      @click="index = imageIndex"
	      :style="{ backgroundImage: 'url(' + image + ')', width: '300px', height: '200px' }"
	    ></div>
    </div>
  </div>
</template>
<script>
  import VueGallery from 'vue-gallery';
  import auth from '../auth';
  import axios from 'axios';
  export default {
    data: function () {
      return {
        images: []
      };
    },
    mounted() {
      const that = this;
        // console.log(auth.getToken()); // I'm text inside the component.
         let accessToken = auth.getToken();
        axios.post('http://localhost:8081/api/default/collections', {
            accessToken: accessToken,
          })
          .then(function (response) {
            // let collections = response.data.data;
            // console.log(collections);
            let list=[];
              response.data.data.map(function(value, key) {
                  list.push("http://localhost:8081/" + value.filepath);
              });
              that.images = list;
          })
          .catch(function (error) {
            console.log(error);
          });
    },

    components: {
      'gallery': VueGallery
    },
  }
</script> 
 
<style scoped>
  .image {
    float: left;
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center center;
    border: 1px solid #ebebeb;
    margin: 5px;
  }
  .col-mb-5 {
  	margin-bottom: 50px;
  }
</style> 