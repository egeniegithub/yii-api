<template>
  <div>
    <h2>Login</h2>
    <p v-if="$route.query.redirect">
      You need to login first.
    </p>
    <form @submit.prevent="login">
      <label>
        <input name="email" type="email" id="email" v-model="email" placeholder="email" class="form-control">
      </label>
      <br />
      <label>
        <input v-model="password" name="password" id="password" placeholder="password" type="password" class="form-control">
      </label> (hint: password1)<br>
      <button type="submit" class="btn btn-primary">login</button>
      <p v-if="error" class="error">Incurrect username or password 
      <!-- Bad login information  -->
      </p>
    </form>
  </div>
</template>

<script>
import auth from '../auth';
import axios from 'axios';

export default {
  data () {
    return {
      email: '',
      password: '',
      error: false,
      accessToken:''
    }
  },
  methods: {
    login () {
        const that = this;
          axios.post('http://localhost:8081/api/default/login', {
            email: this.email,
            password: this.password
          })
          .then(function (response) {
            var obj = JSON.parse(JSON.stringify(response.data));
            // console.log(response);
            if(response.data.data.accessToken){
              auth.login(response.data.data.accessToken, loggedIn => {
                if (!loggedIn) {
                  this.error = true
                } else {
                  that.$router.replace(that.$route.query.redirect || '/art-work')
                }
              })
            } else {
              that.error = true
            }
            
          })
          .catch(function (error) {
            console.log(error);
          });

      // auth.login(this.email, this.pass, loggedIn => {
      //   if (!loggedIn) {
      //     this.error = true
      //   } else {
      //     this.$router.replace(this.$route.query.redirect || '/')
      //   }
      // })
    }
  }
}
</script>

<style>
.error {
  color: red;
}
</style>
