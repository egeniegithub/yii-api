<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Media */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="media-form">

    <?php $form = ActiveForm::begin([
          'options'=>['enctype'=>'multipart/form-data']]); ?>

    <?= $form->field($model, 'image_name')->fileInput(['name'=>'image_name','id'=>'upload_image']) ?>

    	<input type="hidden" name="width" id="width">
    	<input type="hidden" name="height" id="height">
    	
     <!-- <?= $form->field($model, 'width')->hiddenInput(['name'=>'width','id'=>'width']) ?>  -->
     <!-- <?= $form->field($model, 'height')->hiddenInput(['name'=>'height','id'=>'height']) ?>  -->

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
