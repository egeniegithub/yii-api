<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "media".
 *
 * @property int $id
 * @property string $image_name
 * @property string $created_at
 */
class Media extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'media';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['image_name','filepath','height','width','user_id'], 'required'],
            [['image_name'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'image_name' => 'Image Name',
            'filepath' => 'File Path',
            'height'    =>  'Height',
            'width' => 'Width',
            'user_id' => 'User Id'
        ];
    }

    public function fields() {
        return[
            'id',
            'image_name',
            'filepath',
            'user_id',
            'created_at',
        ];
    }
    public function findByUserId($user_id){
        $medias =  self::find()->where(['user_id' => $user_id])->all();
        return $medias;
    }
}
