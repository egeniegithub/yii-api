<?php
namespace app\models;

use Yii;

class NewUser extends \yii\db\ActiveRecord implements \yii\web\IdentityInterface
{
    public $username = 'ali';
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'new_user';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['username','email'],'string','max' => 80],
            [['password','authKey','accessToken'],'string','max' => 255],
        ];
    }

    public function fields() {
        return[
            'id',
            'username',
            'fname',
            'lname',
            'email',
            'accessToken',
            'created_at',
        ];
    }
    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'username' => 'Username',
            'email' => 'Email',
            'password' => 'Password',
        ];
    }

    public static function findIdentity($id){
        return self::findOne($id);
    }
    public static function findIdentityByAccessToken($token,$type=null){
        return self::findOne(['accessToken'=>$token]);
    }
    public static function findByEmail($email){
        return self::findOne(['email'=>$email]);
    }
    public function getId(){
        return $this->id;
    }
    public function getAuthKey(){
        return $this->authKey;
    }
    public function validateAuthKey($authKey){
        return $this->authKey == $authKey;
    }
    public function validatePassword($password){
        return password_verify($password, $this->password);
    }
    public function getIdByAccessToken($accessToken){
        $users =  self::find()->select('id')->where(['accessToken' => $accessToken])->all();
        return $users;
    }
}
